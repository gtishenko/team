self.__precacheManifest = [
  {
    "revision": "b0c5df22289e5c9c8ec9",
    "url": "/static/css/main.627b757d.chunk.css"
  },
  {
    "revision": "b0c5df22289e5c9c8ec9",
    "url": "/static/js/main.3aa6584a.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "a5283a832ecd9e6dbadc",
    "url": "/static/css/2.b43cf360.chunk.css"
  },
  {
    "revision": "a5283a832ecd9e6dbadc",
    "url": "/static/js/2.1cc90672.chunk.js"
  },
  {
    "revision": "cf56eb2611b6d1cd9213103383ed8924",
    "url": "/static/media/grisha.cf56eb26.jpeg"
  },
  {
    "revision": "c3e702f58bc685cb67cbb6d5a5dbbc0d",
    "url": "/static/media/zhenya.c3e702f5.jpeg"
  },
  {
    "revision": "65f70c59c62b2bd91e8e262ccb4856cf",
    "url": "/static/media/tricks.65f70c59.jpeg"
  },
  {
    "revision": "071701f1d84eda03cf9de3a14622e5ed",
    "url": "/index.html"
  }
];